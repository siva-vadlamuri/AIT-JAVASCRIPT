// console.log("JavaScript Works");

document.getElementById('login').addEventListener('click', (event)=>{
    console.log(event);
    
    event.preventDefault();
    let numbers = /^[0-9]+$/;
    let value = document.getElementById('number').value;
    let span = document.getElementById('span-id');
    // console.log(span);
    // console.log(value);
    if(value.match(numbers)){
        span.innerText = "You entered valid numbers";
        span.style.display = "inline"
        span.style.color = "green";
    }
    else{
        // console.log("Enter some numbers");
        span.innerText = "Please enter a  valid numbers";
        span.style.display = "inline"
        span.style.color = 'red';
    }
})