// console.log("JavaScript Works");

document.getElementById('number').addEventListener('keypress', (event)=>{
    // console.log(event);
    // console.log('key pressed');
    event.preventDefault();
    let numbers = /^[0-9]+$/;
    let value = document.getElementById('number').value;
    let span = document.getElementById('span-id');
    // console.log(span);
    console.log(value);
    
    if(!(isNaN(parseInt(value)))){
        span.innerText = "You entered valid numbers";
        span.style.display = "inline"
        span.style.color = "green";
        console.log('I am inside isNaN');
    }
    else{
        // console.log("Enter some numbers");
        span.innerText = "Please enter a  valid numbers";
        span.style.display = "inline"
        span.style.color = 'red';
        console.log('i am outside of isNaN');
    }
})
//  function onKeyPressing(e){
//      e.preventDefault();
//     console.log('key is pressed');
// }