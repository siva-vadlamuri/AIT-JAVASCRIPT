let fruits = new Array();
for(let i=0;i<10;i++){
    let fruit = prompt("Enter a fruit name");

  fruits.push(fruit);
    
}
console.log(fruits);



/**
 * Array methods
 * 1) push
 * 2) pop
 * 3) shift
 * 4) unshif
 * 5) 
 */

let animals = [];

animals.push("dog");
animals.push('cat');
animals.push("bear");
animals.push('lion');
animals.push('baffalo');
console.log(animals);
//pop
animals.pop();

console.log(animals);

//sort

console.log(animals.sort());

//shift
animals.shift()
console.log(`Using shift method ${animals}`);

//unshift
animals.unshift("Jirrafe");
console.log(`Using unshif method ${animals}`);

//length property
console.log(`Length of the arra is ${animals.length}`);

//toString method
console.log(`To string method ${animals.toString}`);

//splice method 
animals.splice(0,1)
console.log(`after splice method value are ${animals}`);